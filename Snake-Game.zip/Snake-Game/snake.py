from turtle import Turtle

LIST_STARTING_SEG_POSITIONS = [(0, 0), (-20, 0), (-40, 0)]

# 90 = up, 270 = down, 180 = left, 0 = right
MOVING_UP = 90
MOVING_DOWN = 270
MOVING_LEFT = 180
MOVING_RIGHT = 0
MOVE_DISTANCE = 20

class Snake:

    # Whenever you create an object of a Class, the init (contructor) is called
    # everything in the contructor is run upon object creation
    def __init__(self):

        # Init list to hold the segements of the snake body
        self.list_snake_segments = []

        # Calls the create snake method when the obj is created, thus initializing our snake segements
        # If we do not have this line of code, the method is not called and our list of snake segs is not populated
        self.create_snake_segements()

        # Set the head of the snake
        # Snake segements are turtle objects (see add_snake_segement)
        self.head = self.list_snake_segments[0]

    # Pass initial starting cords to add snake seg func
    def create_snake_segements(self):

        # Create initial snake body
        for cord in LIST_STARTING_SEG_POSITIONS:
            self.add_snake_segment(cord)

    # Add the snake segements to the list
    def add_snake_segment(self, cord):
        snake = Turtle("square")
        snake.color("white")
        snake.penup()
        snake.goto(cord)
        # Add turtle segement (which is a turtle obj) to a seg list
        self.list_snake_segments.append(snake)

    # Extend the snake
    def extend(self):
        # Adds new seg to the same position as the last seg in the list
        self.add_snake_segment(self.list_snake_segments[-1].position())

    def start_snake(self):

        # Move the snake segements starting from last seg, decementing to the first seg
        # subtract one from each segement position until you reach 0
        # This moves the segements to a position equal to the one before it, granting the snake movement and turning
        # capabilities
        # len(list_sname_segements) - 1 = Start, 0 = stop, - 1 = step(increment/decrement)
        for segment_num in range(len(self.list_snake_segments) - 1, 0, -1):
            # Get cords from the next sgement in the list (current seg - 1 gives us the next segement) ex. 2-1=1
            new_x = self.list_snake_segments[segment_num - 1].xcor()
            new_y = self.list_snake_segments[segment_num - 1].ycor()

            # Moves current seg to new position
            self.list_snake_segments[segment_num].goto(new_x, new_y)

        # Move first seg forward after loop executes
        self.list_snake_segments[0].forward(MOVE_DISTANCE)


    def move_up(self):

        if self.head.heading() != MOVING_DOWN:
            self.head.setheading(MOVING_UP)

    def move_down(self):

        if self.head.heading() != MOVING_UP:
            self.head.setheading(MOVING_DOWN)

    def move_left(self):

        if self.head.heading() != MOVING_RIGHT:
            self.head.setheading(MOVING_LEFT)

    def move_right(self):

        if self.head.heading() != MOVING_LEFT:
            self.head.setheading(MOVING_RIGHT)
