from turtle import Screen
from snake import Snake
from food import Food
from scoreboard import Scoreboard
import time

# Init cords for snake body within a List of Tuples
list_cords = [(0, 0), (-20, 0), (-40, 0)]

# Init list to hold the segements of the snake body
list_snake_segments = []

# Screen setup
screen = Screen()
screen.setup(width = 600, height = 600)
screen.bgcolor("black")
screen.title("Snake Game")
# Turn tracer off by setting it to 0 (stops anything from showing on screen until we call the update() method
screen.tracer(0)

snake = Snake()
food = Food()
scoreboard = Scoreboard()
scoreboard.output_scoreboard()
# start listening for keystrokes (do something specific key is pressed
screen.listen()
screen.onkey(snake.move_up, "Up")
screen.onkey(snake.move_down, "Down")
screen.onkey(snake.move_left, "Left")
screen.onkey(snake.move_right, "Right")

bool_move_cont = True
while bool_move_cont:

    # Update the screen with our snake segements
    screen.update()
    time.sleep(0.1)
    snake.start_snake()

    # Detect collision with food, in pixels
    if snake.head.distance(food) < 15:
        
        food.new_position()
        snake.extend()
        scoreboard.add_to_score()

    # Detect collision with wall.
    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        scoreboard.game_over()
        bool_move_cont = False

    # Detect collision with tail using list slicing.
    # We don't want to loop through the very first item in the segments list
    # because that is the head of the snake which will ofc have a distance of less than 10 from itself
    for segment in snake.list_snake_segments[1:]:
        if snake.head.distance(segment) < 10:
            bool_move_cont = False
            scoreboard.game_over()

screen.exitonclick()