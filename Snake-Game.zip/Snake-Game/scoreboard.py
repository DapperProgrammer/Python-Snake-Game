from turtle import Turtle, Screen
ALIGNMENT = "center"
FONT = ("Arial", 24, "normal")

class Scoreboard(Turtle):

    def __init__(self):

        super().__init__()
        self.score = 0
        self.hideturtle()
        self.penup()
        self.color("white")
        self.goto(0, 260)

    def output_scoreboard(self):
        self.write(f"Score: {self.score}", align = ALIGNMENT, font = FONT)

    def add_to_score(self):
        self.score += 1
        self.clear()
        self.output_scoreboard()

    def game_over(self):
        self.goto(0, 0)
        self.write("Game Over!", align = ALIGNMENT,  font = FONT)

